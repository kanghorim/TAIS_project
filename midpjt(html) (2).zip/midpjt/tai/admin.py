from django.contrib import admin

from tai.models import TACHART

# Register your models here.
admin.site.register(TACHART)
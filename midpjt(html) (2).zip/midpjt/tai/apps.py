from django.apps import AppConfig


class TaiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tai'

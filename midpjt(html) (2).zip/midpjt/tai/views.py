from django.shortcuts import render

# Create your views here.
def tai(request):
    return render(request, 'tai/tai.html') 
from django.contrib import admin
from comm.models import Board, Comment

# Register your models here.
admin.site.register(Board)
admin.site.register(Comment)
 
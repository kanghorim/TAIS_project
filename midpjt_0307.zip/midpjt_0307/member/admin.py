from django.contrib import admin

from member.models import User_Info

# Register your models here.
admin.site.register(User_Info)